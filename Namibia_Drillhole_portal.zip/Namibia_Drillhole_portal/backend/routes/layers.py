from flask import Blueprint, jsonify, request
import psycopg2
import json
from backend.config import Config

layers_bp = Blueprint("layers", __name__)

# -------------------------
# DATABASE HELPER FUNCTION
# -------------------------
def run_query(sql, params=None):
    """Run SQL query and return rows as dictionaries"""
    try:
        with psycopg2.connect(Config.db_uri()) as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params or ())
                cols = [desc[0] for desc in cur.description]
                return [dict(zip(cols, row)) for row in cur.fetchall()]
    except Exception as e:
        print(f"[DB ERROR] {e}")
        return []

# -------------------------
# GEOJSON ENDPOINT FOR DRILLHOLES
# -------------------------
@layers_bp.route("/api/drillholes")
def get_drillholes():
    """
    Fetch drillhole data with optional filters:
      - name (borehole_number)
      - company
      - commodity
    Returns GeoJSON FeatureCollection
    """
    filters = []
    params = []
    sql = """
        SELECT borehole_number, project, epl, company, mineral_groups, commodity,
               exploration_target, purpose, coreshed_availability, project_region, type,
               longitude, latitude, ST_AsGeoJSON(geom) AS geometry
        FROM boreholes
        WHERE 1=1
    """

    # Dynamic filters
    if (name := request.args.get("name")):
        filters.append("borehole_number ILIKE %s")
        params.append(f"%{name}%")
    if (company := request.args.get("company")):
        filters.append("company ILIKE %s")
        params.append(f"%{company}%")
    if (commodity := request.args.get("commodity")):
        filters.append("commodity ILIKE %s")
        params.append(f"%{commodity}%")

    if filters:
        sql += " AND " + " AND ".join(filters)

    rows = run_query(sql, params)

    # Convert to GeoJSON
    features = []
    for row in rows:
        geom_json = row.pop("geometry", None)
        geometry = json.loads(geom_json) if geom_json else None
        features.append({"type": "Feature", "geometry": geometry, "properties": row})

    return jsonify({"type": "FeatureCollection", "features": features})

# -------------------------
# STATIC LAYER ENDPOINT FOR GEOSERVER
# -------------------------
@layers_bp.route("/api/layers")
def get_layers():
    """
    Returns a list of GeoServer WMS layer URLs to be displayed on the map
    """
    base_url = "http://localhost:8080/geoserver/drillholes/wms"
    layers = {
        "roads": f"{base_url}?service=WMS&version=1.1.0&request=GetMap&layers=drillholes:roads",
        "districts": f"{base_url}?service=WMS&version=1.1.0&request=GetMap&layers=drillholes:districts",
        "towns_villages": f"{base_url}?service=WMS&version=1.1.0&request=GetMap&layers=drillholes:towns_villages",
        "regions": f"{base_url}?service=WMS&version=1.1.0&request=GetMap&layers=drillholes:regions",
        "country": f"{base_url}?service=WMS&version=1.1.0&request=GetMap&layers=drillholes:country",
        "farms": f"{base_url}?service=WMS&version=1.1.0&request=GetMap&layers=drillholes:farms",
    }

    return jsonify(layers)

# -------------------------
# SIMPLE HEALTH CHECK
# -------------------------
@layers_bp.route("/api/health")
def health_check():
    """Quick check to verify backend connectivity"""
    return jsonify({"status": "ok", "message": "Layers API running"}), 200
